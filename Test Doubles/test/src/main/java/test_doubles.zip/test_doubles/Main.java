package test_doubles;

public class Main {

	// Main to show the use of the FancyRankingService in the ReservationService
	public static void main(String[] args) {
		ReservationService reservationService = new ReservationService();

		Customer customer = new Customer("Arthur Feu");
		reservationService.reserve(customer);
	}
}
