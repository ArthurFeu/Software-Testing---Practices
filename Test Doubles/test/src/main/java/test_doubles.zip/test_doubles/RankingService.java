package test_doubles;
public interface RankingService {
	int getRank(Customer customer);
}
